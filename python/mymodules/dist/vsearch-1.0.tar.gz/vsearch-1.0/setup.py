from setuptools import setup

setup(
    name = 'vsearch',
    version='1.0',
    description='The Head First Python Search Tools',
    author='whj',
    author_email='1004609378@qq.com',
    url='headfirstlabs.com',
    py_modules=['vsearch']
)